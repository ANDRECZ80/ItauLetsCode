package br.com.letscode.turmaitau;

public class TiposPrimitivosInteiros {

    public static void main(String[] args) {

        short b = 1;
        int   numeroInt = 5;
        long  numeroLong = 5;

        int soma = numeroInt + 10;

        System.out.println("soma = " + soma);

    }
}

package br.com.letscode.turmaitau.contabancaria;

public class PessoaJuridica extends Pessoa{

    private String cnpj;

}

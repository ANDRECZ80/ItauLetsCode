package br.com.letscode.turmaitau.contabancaria;

public abstract class Pessoa {

    private String nome;
    private String telefone;


}

package br.com.letscode.turmaitau.contabancaria;

public class PessoaFisica extends Pessoa{

    private String cpf;

}

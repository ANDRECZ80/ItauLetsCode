package br.com.letscode.turmaitau.cestaprodutos;

public class CestaProdutosMain {

    public static void main(String[] args){

        CalculaCestaProdutos calculaCestaProdutos = new CalculaCestaProdutos();
        calculaCestaProdutos.recuperarDadosECalcular();
    }
}

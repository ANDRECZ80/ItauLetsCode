package br.com.letscode.turmaitau;

import java.util.Arrays;

public class PrimeiraClasse {

    public static void main(String[] args) {

        byte nomeVariavelByte = 'A';

        System.out.println("byte = " + nomeVariavelByte);
        System.out.print("Itau");
    }
   }


